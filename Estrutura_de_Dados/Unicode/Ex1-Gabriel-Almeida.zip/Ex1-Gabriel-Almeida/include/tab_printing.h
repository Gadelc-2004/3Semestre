#ifndef TAB_PRINTING_H
#define TAB_PRINTING_H

void imprimir_colunas(int y, wchar_t bar, wchar_t trace, wchar_t l, wchar_t r); 
void imprimir_linhas(int x, int y, wchar_t bar, wchar_t abar, wchar_t trace, wchar_t t, wchar_t d, wchar_t midle, wchar_t tl, wchar_t tr, wchar_t dl, wchar_t dr, wchar_t bl, wchar_t br, wchar_t abl, wchar_t abr);

#endif 
